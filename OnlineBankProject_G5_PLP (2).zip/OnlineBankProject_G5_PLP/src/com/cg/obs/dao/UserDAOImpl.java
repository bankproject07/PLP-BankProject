package com.cg.obs.dao;

import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.FundTransfer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;


@Repository("userDao")
public class UserDAOImpl implements IUserDAO{

	@PersistenceContext
	private EntityManager entityManager;
	
	public UserDAOImpl() {
		// TODO Auto-generated constructor stub
	}
	
	
	public UserDAOImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}



	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}




	@Override
	public Users getUser(int id) throws UserException {
		Users user=null;
	try{
			
			
			user=entityManager.find(Users.class,id);
		//	entityManager.flush();
			
		
		}
		catch(Exception e)
		{
		
			throw new UserException("exception occured:"+e.getMessage());
		}
		if(user==null)
		{
			throw new UserException("No User found with id="+id);
		}
	
		return user;
	}

	@Override
	public void registerUser(Users user) throws UserException {
		// TODO Auto-generated method stub
		
	}


		@Override
		public List<Transactions> getMiniTransactions(Long accountno) throws UserException {
			

			List<Transactions> transactions=null;
			try 
			{
				/*EntityTransaction transaction=entityManager.getTransaction();
				transaction.begin();*/
				String qStr="select t from Transaction t where t.Account_ID=:Account_ID ";
				TypedQuery<Transactions> query=entityManager.createQuery(qStr,Transactions.class);
				query.setParameter("accountno",accountno);
				
				transactions=query.getResultList();
			}
			catch (Exception e) 
			{
				throw new UserException(e.getMessage());
			}
			
			if(transactions==null || transactions.isEmpty())
			{
				throw new UserException("No transaction to display ");
			}
			return transactions;
			
			
		}
	

	@Override
	public int getCustomerId(Long accountno) throws UserException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer getCustomer(int customerid) throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateCustomerDetails(Customer customer) throws UserException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int requestService(ServiceTracker services) throws UserException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ServiceTracker getRequestedServiceList(int requestid)
			throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int fundTransfer(FundTransfer transferInfo) throws UserException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void insertTransaction(Transactions transaction)
			throws UserException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBalance(double Updatedbalance, Long accountNo)
			throws UserException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updatePayeeBalance(double Updatedbalance, Long accountNo)
			throws UserException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changePassword(Users user) throws UserException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateLockStatus(int userid) throws UserException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Payee> getPayee(long accountid) throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertPayee(Payee payee) throws UserException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isPayeeAccountExists(long payeeAccountNo)
			throws UserException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public AccountMaster getAccount(long accountno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int registerUser(Users user, Customer customer) throws UserException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int addRequest(RequestTable resTab) throws UserException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public RequestTable getAccountId(int custId) throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int isCheckBookRequestExist(Long accountno) throws UserException {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public List<Transactions> getDetailedTransactions(Long accountno,
			Date fromDate, Date toDate) throws UserException {
		// TODO Auto-generated method stub
		return null;
	}
	
	


	
}
