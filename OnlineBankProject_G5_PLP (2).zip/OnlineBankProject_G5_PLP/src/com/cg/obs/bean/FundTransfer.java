package com.cg.obs.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Fund_Transfer")

public class FundTransfer {

	@Id
	private int fundTransfer_Id;
	private long account_Id;
	private long payee_Account;
	private Date dateOfTransfer;
	private Double transferAmount;
	public FundTransfer(int fundTransfer_Id, long account_Id, long payee_Account, Date dateOfTransfer,
			Double transferAmount) {
		super();
		this.fundTransfer_Id = fundTransfer_Id;
		this.account_Id = account_Id;
		this.payee_Account = payee_Account;
		this.dateOfTransfer = dateOfTransfer;
		this.transferAmount = transferAmount;
	}
	public FundTransfer() {
		super();
	}
	
	
	
	
	
	
	public int getFundTransfer_Id() {
		return fundTransfer_Id;
	}
	public void setFundTransfer_Id(int fundTransfer_Id) {
		this.fundTransfer_Id = fundTransfer_Id;
	}
	public long getAccount_Id() {
		return account_Id;
	}
	public void setAccount_Id(long account_Id) {
		this.account_Id = account_Id;
	}
	public long getPayee_Account() {
		return payee_Account;
	}
	public void setPayee_Account(long payee_Account) {
		this.payee_Account = payee_Account;
	}
	public Date getDateOfTransfer() {
		return dateOfTransfer;
	}
	public void setDateOfTransfer(Date dateOfTransfer) {
		this.dateOfTransfer = dateOfTransfer;
	}
	public Double getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(Double transactionAmount) {
		this.transferAmount = transactionAmount;
	}
	@Override
	public String toString() {
		return "FundTransfer [fundTransfer_Id=" + fundTransfer_Id + ", account_Id=" + account_Id + ", payee_Account="
				+ payee_Account + ", dateOfTransfer=" + dateOfTransfer + ", transferAmount=" + transferAmount + "]";
	}
	

	
	
}
