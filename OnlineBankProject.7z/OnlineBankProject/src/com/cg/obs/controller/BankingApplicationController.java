package com.cg.obs.controller;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jboss.security.ISecurityManagement;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;
import com.cg.obs.service.IUserService;
import com.cg.obs.service.UserServiceImpl;


@WebServlet(urlPatterns={"/BankingApplicationController","/Login","/Adminlogin","/viewTransaction","/Daily","/Monthly","/Yearly",
		"/Registration","/AdminPage","/CreateAcc","/InsertAccount"})
public class BankingApplicationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IUserService userService;
    public BankingApplicationController() {
        
    	userService=new UserServiceImpl();
    }

	public void init(ServletConfig config) throws ServletException
	{
		
	}

	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String path=request.getServletPath();
		String url="";

		List<Transactions> tList =null;
		switch(path)
		{
		case "/Login":
			
			String id=request.getParameter("txtUserName");
			String password=request.getParameter("txtPassword");
			
			int hitCounter=0;
			Users user=userService.getUser(Integer.parseInt(id));
			System.out.println(user);
			if(user!=null)
				{
				if(user.getLockStatus()!="L")
					
				{
					
					if(password.equalsIgnoreCase(user.getLoginPassword()))
					{
						System.out.println(user.getLoginPassword());
						url="Sucess.jsp";
						request.setAttribute("userid", user.getUserId());
					}
					else
					{
						hitCounter++;
						System.out.println(hitCounter);
						if(hitCounter==3)
						{
							userService.updateLockStatus(user.getUserId());
							System.out.println("Your Account Locked");
							url="#";
						}
					url="#";
					}
				}
				else
				{
					System.out.println("Wrong Password"+hitCounter);
				}
				}
		else
		{
			throw new UserException("No User Exists.....");
		}
			break;
		
		case "/Adminlogin":
			String adUser = request.getParameter("username");
			String pass = request.getParameter("password");
			if(adUser.equalsIgnoreCase("cartoon")&&pass.equalsIgnoreCase("cartoon"))
				{
					url ="Projects/pages/AdminAccount.jsp";
				}
			
			break;
				
		
		case "/Daily":
			
			String startDate = request.getParameter("date");
			java.sql.Date sqlStartDate;
			try
			{
				SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date date = sdf1.parse(startDate);
				sqlStartDate = new java.sql.Date(date.getTime());
				
				tList = userService.viewDailyReport(sqlStartDate);
				request.setAttribute("tList", tList);
				
				url="./Projects/pages/DailyTransactions.jsp";
				
			} 
			catch (ParseException e) 
			{
				System.out.println(e.getMessage());
			}
			catch (Exception e)
			{
				System.out.println(e.getMessage());
			}
			break;
			
		case "/Monthly":
			String strtDate = request.getParameter("sdate");
			java.sql.Date sqlStrtDate;
			String endDate = request.getParameter("edate");
			java.sql.Date sqlEndDate;
			try
			{
				SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date sdate = sdf1.parse(strtDate);
				sqlStrtDate = new java.sql.Date(sdate.getTime());
				
				SimpleDateFormat edf1 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date edate = edf1.parse(endDate);
				sqlEndDate = new java.sql.Date(edate.getTime());
				
				tList = userService.viewMonthlyReport(sqlStrtDate, sqlEndDate);
				request.setAttribute("tList", tList);
				url="./Projects/pages/MonthlyTransactions.jsp";
				
			} 
			catch (ParseException e) 
			{
				System.out.println(e.getMessage());
			}
			catch (Exception e)
			{
				System.out.println(e.getMessage());
			}
			break;
			
		case "/Yearly":
			
			String sDate = request.getParameter("sdate");
			java.sql.Date sqlSDate;
			String eDate = request.getParameter("edate");
			java.sql.Date sqlEDate;
			try
			{
				SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date sdate = sdf2.parse(sDate);
				sqlSDate = new java.sql.Date(sdate.getTime());
				
				SimpleDateFormat edf2 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date edate = edf2.parse(eDate);
				sqlEDate = new java.sql.Date(edate.getTime());
				
				tList = userService.viewYearlyReport(sqlSDate, sqlEDate);
				request.setAttribute("tList", tList);
				url="./Projects/pages/YearlyTransactions.jsp";
				
			} 
			catch (ParseException e) 
			{
				System.out.println(e.getMessage());
			}
			catch (Exception e)
			{
				System.out.println(e.getMessage());
			}
			
			break;
		case "/Registration":
			
			RequestTable resTab= new RequestTable();
			int custid = Integer.parseInt(request.getParameter("txtCustId"));
			String type = request.getParameter("question");
			if(userService.isCustomerExist(custid))
			{
			
				resTab.setCustId(custid);
				resTab.setType(type);
			
				int accid = userService.addRequest(resTab);
				
				request.setAttribute("AccountId", accid);
				url="/Projects/pages/RegistrationSuccess.jsp";
			}
			
			else
			{
				String err = "Customer Doesnt't Exist";
				request.setAttribute("error", err);
				url="Projects/pages/NewAccount.jsp";
				
			}
			break;
			
		case "/AdminPage":
			List<RequestTable> req_List = userService.getAllRequest();
			request.setAttribute("List", req_List);
			
			url="./Projects/pages/ViewRequestPage.jsp";
		break;
		
		case "/CreateAcc":
			
			String cust_ID = request.getParameter("custId");
			int cust = Integer.parseInt(cust_ID);
	
			RequestTable req = new RequestTable();
			Customer customer = new Customer();
			
			customer = userService.getCustomer(cust);
			req= userService.getAccountId(cust);
			
			request.setAttribute("customer", customer);
			request.setAttribute("Request", req);
			
			url ="./Projects/pages/CreateAccount.jsp";
			
			break;
			
		case "/InsertAccount":
			
			int accountID = Integer.parseInt(request.getParameter("accountId"));
			String a_type= request.getParameter("txtacctype");
			float balance= Float.parseFloat(request.getParameter("txtbalance"));
			String open_date = request.getParameter("txtdate");
			int cus_ID = Integer.parseInt(request.getParameter("txtcustid"));
			try
			{
				DateTimeFormatter format =DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate localDate = LocalDate.parse(open_date, format);
				java.sql.Date openSqlDate = java.sql.Date.valueOf(localDate);
				
				
				if(userService.isCustomerExist(cus_ID))
				{
				
					AccountMaster account = new AccountMaster();
					account.setAccountId(accountID);
					account.setAccountType(a_type);
					account.setCust_id(cus_ID);
					account.setAccount_bal(balance);
					account.setOpen_date(openSqlDate);
					
					int account_id = userService.addUsers(account);
					request.setAttribute("Account_ID",account_id);
					
					url="Projects/pages/SuccessReg.jsp";
				}
				else
				{
					String err = "Customer Doesnt exist \n Unable to add account";
					request.setAttribute("error", err);
					url="Projects/pages/CreateAccount.jsp";
				
				}
				
			}
		
			catch (Exception e) 
			{
				throw new UserException("Unable to add Account" +e.getMessage());
			}
			break;
		}
				
	
			RequestDispatcher rd=request.getRequestDispatcher(url);
			rd.forward(request, response);
			
			
			
		}
		
		
		
		
	}


